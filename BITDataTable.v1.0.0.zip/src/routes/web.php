<?php
/**
 * Created by PhpStorm.
 * User: Cacing
 * Date: 12/07/2019
 * Time: 14:54
 */
Route::get('dtb/test', function(){
    return 'dtb loaded!';
});
